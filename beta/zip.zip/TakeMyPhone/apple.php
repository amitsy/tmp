
<?php
	
	$brand=$_POST['cat'];
echo $brand;
	?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta  charset=UTF-8>
        <title>Sell your used mobiles and second hand mobiles in India | TakeMyPhone</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
        <link rel="stylesheet" type="text/css" href="css/logostyle.css" />
         <link rel="stylesheet" type="text/css" href="css/style.css" />
         <link rel="stylesheet" type="text/css" href="css/footbar.css" />
         <link rel="stylesheet" type="text/css" href="css/footerstyle.css" />
         <link rel="stylesheet" type="text/css" href="css/style_common.css" />
        <link rel="stylesheet" type="text/css" href="css/style1.css" />
        <link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css' />
        <link rel="stylesheet" href="css/menustyle.css" type="text/css" media="screen"/>
        <link rel="stylesheet" type="text/css" href="css/btnstyle.css" />
        <link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css' />
        <link href='http://fonts.googleapis.com/css?family=Terminal+Dosis' rel='stylesheet' type='text/css' />
    </head>
    <body>
        <div id="container" >
            <div class="row">
                <div id="logo" class="span4">
                    
                    <ul class="ca-menu">
                    <li>
                        <a href="#">
                            <span class="ca-icon"><img src="src/logo1.png"></span>
                            <div class="ca-content">
                                <h2 class="ca-main">TakeMyPhone</h2>
                                <h3 class="ca-sub">Sell your used mobiles in 30 seconds</h3>
                            </div>
                        </a>
                    </li>
                    
                    </ul>
                </div>
                <div id="menu" class="span8">
                    
                    <div class="mcontainer">
            <ul id="menu">
                <li>
                    <a>
                        <i class="icon_about"></i>
                        <span class="title">Products</span>
                        <span class="description">See all the phones we take</span>
                    </a>
                </li>
                <li>
                    <a>
                        <i class="icon_work"></i>
                        <span class="title">How We Work</span>
                        <span class="description">Its simple to sell to TakeMyPhone</span>
                    </a>
                </li>
                <li>
                    <a>
                        <i class="icon_help"></i>
                        <span class="title">Help</span>
                        <span class="description">Contact Us or see FAQs</span>
                    </a>
                </li>
                <li>
                    <a>
                        <i class="icon_search"></i>
                        <span class="title">Login</span>
                        <span class="description">Track your order</span>
                    </a>
                </li>
            </ul>
                     </div>
                    
                    
                </div>
            </div>

 <?php 
mysql_connect('thegmatassassins.netfirmsmysql.com', 'takemyphone1', 'Takemyphone24*7'); 
mysql_select_db(takemyphone); 

?> 
            
                <div id="productbox" class="span11 offset4">
				<?php
				
				
				
			$sql="select * from products where brand='$brand'";
$res= mysql_query($sql);
$n= mysql_num_rows($res);
$i=1;
echo "clll";
echo $n;
while($i<=$n)
{
 $row=mysql_fetch_array($res);
			?>
                    <div class="view view-first">
                    <img src="src/$id.jpg" />
                    <div class="mask">
                        <h2><?php echo $row['name']; ?></h2>
                        <p>Click here to get your offer</p>
                        <a href="#" class="info">Read More</a>
                    </div>
                </div>  
                <?php $i++; } ?>
            </div>
                    
                    
                    
                    
            </div>
            <div class="span12 offset4" id="footbar">
                
            </div>
            <div class="span12" id="footer">
                <div id="aboutus" class="footeritems">
                    <h3>About Us</h3>
                    
            </div>
                <div id="information" class="footeritems">
                    <h3>Information</h3>
                    
                </div>
                <div id="Products" class="footeritems">
                    <h3>Products</h3>
                </div>
                <div id="contactus" class="footeritems">
                    <h3>Contact Us</h3>
                </div>
        </div>
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js"></script>
        <script type="text/javascript">
       $(function() {
            $('#menu > li').hover(
                function () {
                    var $this = $(this);
                    $('a',$this).stop(true,true).animate({
                            'bottom':'-15px'
                        }, 300);
                    $('i',$this).stop(true,true).animate({
                            'top':'-10px'
                        }, 400);
                },
                function () {
                    var $this = $(this);
                    $('a',$this).stop(true,true).animate({
                            'bottom':'-95px'
                        }, 300);
                    $('i',$this).stop(true,true).animate({
                            'top':'50px'
                        }, 400);
                }
            );
        });
</script>
    </body>
</html>
